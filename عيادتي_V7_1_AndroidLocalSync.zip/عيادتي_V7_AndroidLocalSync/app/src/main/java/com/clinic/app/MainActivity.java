package com.clinic.app;

import android.app.*;import android.os.*;import android.webkit.*;import android.graphics.Color;import java.io.*;import java.net.*;import java.util.*;import java.util.concurrent.*;import android.content.*;

public class MainActivity extends Activity {
  WebView web; LocalSync sync;
  @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.setBackgroundColor(Color.WHITE); WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); web.addJavascriptInterface(new Bridge(),"AndroidSync"); sync=new LocalSync(this); sync.start(); web.loadUrl("file:///android_asset/index.html"); setContentView(web);}
  class Bridge { @JavascriptInterface public void sendDB(String db){sync.setLatest(db);} @JavascriptInterface public String status(){return sync.connected?"connected":"searching";} }
  @Override protected void onDestroy(){if(sync!=null)sync.stop();super.onDestroy();}
  class LocalSync {
    final int PORT=39090, UDP=39091; volatile boolean running,connected; volatile String latest="";
    ExecutorService pool=Executors.newCachedThreadPool(); DatagramSocket udp; ServerSocket server;
    Set<Socket> sockets=ConcurrentHashMap.newKeySet(); Set<String> peers=ConcurrentHashMap.newKeySet();
    LocalSync(Context c){}
    void start(){running=true; pool.execute(this::serverLoop); pool.execute(this::udpLoop); pool.execute(this::announceLoop);}
    synchronized void setLatest(String s){if(s==null||s.isEmpty())return; latest=s; broadcast(s);}
    synchronized String getLatest(){return latest;}
    void serverLoop(){
      try{server=new ServerSocket(PORT); server.setReuseAddress(true);
        while(running){Socket s=server.accept(); sockets.add(s); pool.execute(()->handle(s));}
      }catch(Exception ignored){}
    }
    void handle(Socket s){
      connected=true;
      try{
        s.setKeepAlive(true); s.setTcpNoDelay(true);
        BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream()));
        PrintWriter w=new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())),true);
        String mine=getLatest(); if(!mine.isEmpty()) w.println(mine);
        String l; while(running&&(l=r.readLine())!=null){
          if(l.startsWith("{")){ final String x=l; setLatest(x); postToJs(x); }
        }
      }catch(Exception ignored){}
      finally{try{s.close();}catch(Exception ignored){} sockets.remove(s); if(sockets.isEmpty())connected=false;}
    }
    void postToJs(String x){new Handler(Looper.getMainLooper()).post(()->{try{if(web!=null)web.evaluateJavascript("window.onNativeSync("+quote(x)+")",null);}catch(Exception ignored){}});}
    String quote(String x){return "'"+x.replace("\\","\\\\").replace("'","\\'").replace("\n","\\n").replace("\r","\\r")+"'";}
    void udpLoop(){
      while(running){
        try{
          udp=new DatagramSocket(UDP); udp.setReuseAddress(true); udp.setBroadcast(true);
          byte[] b=new byte[1024];
          while(running){DatagramPacket p=new DatagramPacket(b,b.length); udp.receive(p); String m=new String(p.getData(),0,p.getLength());
            if(m.startsWith("CLINIC_SYNC_V7|")){String ip=p.getAddress().getHostAddress(); if(!ip.equals(getLocalIp())) connect(ip);}
          }
        }catch(Exception ignored){} finally{if(udp!=null)udp.close();}
        try{Thread.sleep(300);}catch(Exception ignored){}
      }
    }
    void announceLoop(){
      while(running){
        try{
          for(String bc: getBroadcasts()){
            DatagramSocket s=new DatagramSocket(); s.setReuseAddress(true); s.setBroadcast(true);
            byte[] b=("CLINIC_SYNC_V7|"+PORT).getBytes(); s.send(new DatagramPacket(b,b.length,InetAddress.getByName(bc),UDP)); s.close();
          }
          Thread.sleep(1200);
        }catch(Exception ignored){try{Thread.sleep(700);}catch(Exception z){}}
      }
    }
    List<String> getBroadcasts(){
      ArrayList<String> out=new ArrayList<>();
      try{Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces(); while(en.hasMoreElements()){
        NetworkInterface ni=en.nextElement(); if(!ni.isUp()||ni.isLoopback())continue;
        for(InterfaceAddress ia:ni.getInterfaceAddresses()){InetAddress b=ia.getBroadcast(); if(b!=null)out.add(b.getHostAddress());}
      }}catch(Exception ignored){}
      if(out.isEmpty())out.add("255.255.255.255"); return out;
    }
    void connect(String ip){
      if(!running||ip==null||ip.isEmpty()||ip.equals(getLocalIp())||peers.contains(ip))return;
      peers.add(ip); pool.execute(()->{try{Socket s=new Socket(); s.setKeepAlive(true); s.setTcpNoDelay(true); s.connect(new InetSocketAddress(ip,PORT),1000); sockets.add(s); handle(s);}catch(Exception ignored){}finally{peers.remove(ip);}});
    }
    void broadcast(String db){for(Socket s:new ArrayList<>(sockets)){try{PrintWriter w=new PrintWriter(new BufferedWriter(new OutputStreamWriter(s.getOutputStream())),true);w.println(db);}catch(Exception ignored){}}}
    String getLocalIp(){try{Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();while(en.hasMoreElements()){NetworkInterface ni=en.nextElement();if(!ni.isUp()||ni.isLoopback())continue;Enumeration<InetAddress> as=ni.getInetAddresses();while(as.hasMoreElements()){InetAddress a=as.nextElement();if(!a.isLoopbackAddress()&&a instanceof Inet4Address)return a.getHostAddress();}}}catch(Exception ignored){}return "";}
    void stop(){running=false;try{if(server!=null)server.close();}catch(Exception ignored){}for(Socket s:sockets)try{s.close();}catch(Exception ignored){}if(udp!=null)udp.close();pool.shutdownNow();}
  }
}
